using UnityEngine;

public class Player : MonoBehaviour
{
    // ��� �÷��̾��� ����
    public int playerId { get; set; }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
