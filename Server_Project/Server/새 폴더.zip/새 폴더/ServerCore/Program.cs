﻿using System;

namespace ServerCore
{
/*    class Program
    {
        static void Main(string[] args)
        {

        }
    }*/

}