﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using static System.Collections.Specialized.BitVector32;

namespace ServerCore
{

    //내용 전부 서버에 옮김
    //이제 이 서버 코어는 클래스 라이브러리화 되었음
}